# ตั๋วปริศนา: ราตรีงานวัด

เกมทดสอบตัวตนธีมงานวัด 12 ฉาก พร้อมระบบเสียง (BGM / Ambient / SFX) แบบ fade in-out และ UI ปิด-เปิดเสียงสไตล์ visual novel

## โครงสร้างไฟล์

```
index.html      หน้าเว็บหลัก
style.css       สไตล์ทั้งหมด (ฉาก, ฟ้า, ฝน, พลุ, UI เสียง)
script.js       ตรรกะเกม ฉาก ตัวเลือก คะแนน เอฟเฟกต์ภาพ
audio.js        AudioManager: bgm / ambient / sfx + fade + unlock มือถือ
assets/audio/
  bgm/          เพลงประกอบพื้นหลัง (loop ตลอดเกม)
  ambient/      เสียงบรรยากาศ (งานวัด / ฝน) สลับกันตามฉาก
  sfx/          เสียงเอฟเฟกต์สั้นๆ (คลิก, เลือก, พลุ, ระฆัง, ฟ้าร้อง, จบเกม)
```

## ต้องใส่ไฟล์เสียงเอง

โค้ดอ้างอิงไฟล์เหล่านี้ไว้แล้วใน `script.js` (ตัวแปร manifest) — ถ้ายังไม่มีไฟล์ เกมจะยังเล่นได้ปกติ แค่จะไม่มีเสียง (มี fallback + console warning ไม่ทำให้เกมพัง):

| ตำแหน่ง | ไฟล์ที่ต้องใส่ | คำแนะนำ |
|---|---|---|
| `assets/audio/bgm/theme.mp3` | เพลงประกอบหลัก | วนลูปได้ลื่น ๆ (seamless loop), บรรยากาศงานวัด/เทศกาล |
| `assets/audio/ambient/festival.mp3` | เสียงบรรยากาศงานวัดทั่วไป | เสียงคนคุย เพลงจากลำโพง เสียงฝูงชนเบาๆ |
| `assets/audio/ambient/rain.mp3` | เสียงฝนตก | ใช้ตอนฉากที่ 6-7 |
| `assets/audio/sfx/click.mp3` | เสียงคลิกทั่วไป | ปุ่ม/ตั๋ว |
| `assets/audio/sfx/select.mp3` | เสียงเลือกตัวเลือก | สั้น กระชับ |
| `assets/audio/sfx/firework.mp3` | เสียงพลุระเบิด | ใช้ทั้งพลุพื้นหลังและพลุฉากที่ 11/ตอนจบ |
| `assets/audio/sfx/bell.mp3` | เสียงระฆัง | ใช้ในฉากสุดท้าย |
| `assets/audio/sfx/ending.mp3` | เสียงตอนขึ้นหน้าผลลัพธ์ | |
| `assets/audio/sfx/thunder.mp3` | เสียงฟ้าร้องเบาๆ | สุ่มเล่นระหว่างฉากฝนตก |

ใช้ไฟล์ `.mp3` เป็นหลัก (รองรับกว้างสุดทั้ง desktop/mobile) ไฟล์เสียงฟรีลิขสิทธิ์ถูกต้องหาได้จากแหล่งอย่าง Pixabay Audio, Freesound (เช็ก license เป็น CC0/CC-BY ก่อนใช้งานจริงเสมอ)

หากต้องการเปลี่ยนชื่อไฟล์/นามสกุล แก้ได้ที่ตัวแปร `manifest` ใน `script.js` (ค้นหา `fairAudio.init(`)

## ระบบเสียงทำงานอย่างไร

- **BGM** เล่นวนตลอดเกม เริ่มเมื่อผู้เล่นกดปุ่ม "ก้าวเข้าสู่ซุ้มประตู" (เป็น user gesture แรกที่ปลดล็อกเสียงบนมือถือ)
- **Ambient** สลับ crossfade ระหว่าง `festival` ↔ `rain` อัตโนมัติตามฉาก (ฉาก 6-7 = ฝน)
- **SFX** เล่นแบบ clone node ทำให้เสียงซ้อนกันได้ (เช่นพลุหลายลูกพร้อมกัน) โดยไม่ตัดเสียงเดิม
- ทุกการเปลี่ยนระดับเสียง/สลับแทร็กจะ **fade** เสมอ ไม่มีการตัดเสียงห้วน ๆ
- ตั้งค่า (mute + ระดับเสียงแต่ละหมวด) ถูกจำไว้ใน `localStorage` เปิดเกมใหม่ก็ยังจำค่าที่ตั้งไว้

## UI ควบคุมเสียง

มุมขวาบนของจอมีปุ่ม 2 ปุ่ม:
- ปุ่มลำโพง — ปิด/เปิดเสียงทั้งหมดทันที (fade)
- ปุ่มเฟือง — เปิดแผงเลื่อนปรับระดับเสียงแยก 3 หมวด (เพลงประกอบ / บรรยากาศ / เอฟเฟกต์)

## รันบนเครื่องผ่าน VS Code

เปิดโฟลเดอร์นี้ใน VS Code แล้วใช้ extension **Live Server** (คลิกขวาที่ `index.html` → "Open with Live Server") เพื่อให้ path เสียง/ฟอนต์โหลดถูกต้อง (การเปิดไฟล์ตรง ๆ แบบ `file://` อาจโดนเบราว์เซอร์บล็อกการโหลดบางไฟล์)

## Deploy ขึ้น GitHub Pages

1. สร้าง repository ใหม่บน GitHub แล้ว push โฟลเดอร์นี้ทั้งหมดขึ้นไป (รวมโฟลเดอร์ `assets/audio` ที่ใส่ไฟล์เสียงจริงแล้ว)
   ```bash
   git init
   git add .
   git commit -m "init: temple fair mbti game"
   git branch -M main
   git remote add origin <URL ของ repo>
   git push -u origin main
   ```
2. ไปที่ repo บน GitHub → **Settings → Pages**
3. ในหัวข้อ **Build and deployment** เลือก Source เป็น **Deploy from a branch**
4. เลือก branch `main` และโฟลเดอร์ `/ (root)` แล้วกด Save
5. รอสักครู่ GitHub จะให้ลิงก์ประมาณ `https://<username>.github.io/<repo>/` — เข้าลิงก์นี้เพื่อเล่นเกม

ไม่ต้อง build/bundle ใด ๆ เพราะเป็น static site (HTML/CSS/JS ล้วน) ใช้งานได้กับ GitHub Pages ทันที
